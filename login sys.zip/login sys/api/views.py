from django.shortcuts import render

# Create your views here.
from rest_framework import generics
from account.models import Account
from .serializers import AccountSerializer

class AccountAPIView(generics.ListAPIView):
    queryset = Account.objects.all()
    serializer_class = AccountSerializer