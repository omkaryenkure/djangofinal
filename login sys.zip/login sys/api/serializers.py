from rest_framework import serializers
from account.models import Account
class AccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = Account
        fields = ['C_name','Bank_balance','Salary','Rent','Groceries','Heath_and_insurance','Clothing','Transport','shares_profit']
