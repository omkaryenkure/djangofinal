from django.contrib import admin
from django.urls import path,include
from account import views
from django.http import HttpResponse
from account import forms
from django.contrib.auth.views import LoginView
urlpatterns = [
    path('', views.Login, name='Login'),
    path('accounts', views.account_list,name='account_list'),
    path('Logout', views.Logout),
    path('users',views.user_list,name='user_list'),
    path('view/<int:pk>/', views.account_view, name='account_view'),
    path('new', views.account_create,name='account_new'),
    path('user_new',views.user_create,name='user_create'),
  #  path('view/<int:pk>', views.AccountView.as_view(), name='account_view'),
    path('edit/<int:pk>', views.account_update, name='account_edit'),
    path('delete/<int:pk>', views.account_delete, name='account_delete'),
    path("register/", views.register, name="register"),
    path("email_v/", views.emailver, name="email_v"),
    path('', include('django.contrib.auth.urls')),
    path('chart/', views.chart, name='chart'),
    path('log', views.index),
  #  path('accounts/login/', LoginView.as_view(authentication_form=forms.OTPAuthenticationForm), name="login"),

]