from django.shortcuts import render,redirect,get_object_or_404,HttpResponse
from django import forms
from .models import Account,Profile
from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm,PasswordResetForm
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from .forms import RegisterForm,OTPAuthenticationForm
from django.contrib.auth.decorators import login_required
import math, random
from django.core.mail import send_mail
from django.conf import settings
class AccountForm(ModelForm):
    class Meta:
        model = Account
        fields = ['C_name','Bank_balance','Salary','Rent','Groceries','Heath_and_insurance','Clothing','Transport','shares_profit']
class UserForm(ModelForm):
    class Meta:
        model = Profile
        fields=['C_name','bank_name','IFSC_code','Address','city']
def user_create(request,template_name='user_form.html'):
    form = UserForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('user_list')
    return render(request,template_name , {'form': form})
def user_list(request):
    context = {}

    # add the dictionary during initialization
    context["object_list"] = Profile.objects.all()

    return render(request, "user_list.html", context)
def Login(request):
    if request.method == 'POST':
        username=request.POST.get('username')
        password=request.POST.get('password')
        user = authenticate(request,username=username,password=password)
        if user is not None:
            login(request,user)
            return redirect('account_list')
    context = {}
    return render(request,'login.html',context)

def Logout(request):
    logout(request)
    return redirect('Login')

def account_list(request):
    context = {}
    context["object_list"] = Account.objects.all()
    return render(request, "account_list.html", context)
def account_view(request, pk, template_name='account_details.html'):
    account = get_object_or_404(Account, pk=pk)
    return render(request, template_name, {'object': account})

def account_create(request, template_name='account_form.html'):
    form = AccountForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('account_list')
    return render(request, template_name, {'form': form})
def account_update(request, pk, template_name='account_form.html'):
    account = get_object_or_404(Account, pk=pk)
    form = AccountForm(request.POST or None, instance=account)
    if form.is_valid():
        form.save()
        return redirect('account_list')
    return render(request, template_name, {'form': form})

def account_delete(request, pk, template_name='account_confirm_delete.html'):
    account= get_object_or_404(Account, pk=pk)
    if request.method=='POST':
        account.delete()
        return redirect('account_list')
    return render(request, template_name, {'object': account})
from django.shortcuts import render, redirect
from .forms import RegisterForm


x = 0
k = 0
# Create your views here.
def register(response):
    if response.method == "POST":
        form = RegisterForm(response.POST)
        if form.is_valid():
            form.save()
            global x
            x = str(generateOTP())
            y = str(form['email'].value())
            print(y)
            subject = "Your OTP Password",
            message = "Your OTP password is %s" % x
            send_mail(subject, message,settings.EMAIL_HOST_USER, [y], fail_silently=False)
            return redirect("email_v")
    else:
        form = RegisterForm()

    return render(response, "register.html", {"form":form})
def emailver(request):
    if request.method == "POST":
        global k
        if(request.POST['Otp'] == x):
            k=1
            return redirect("account_list")
        else:
            k=0
    return render(request,"email_v.html")
def password_reset(request):
    if request.method == "POST":
        password_reset_form = PasswordResetForm(request.POST)
        if password_reset_form.is_valid():
            data = password_reset_form.cleaned_data['email']
            associated_users = User.objects.filter(Q(email=data))
            if associated_users.exists():
                for user in associated_users:
                    subject = "Password Reset Requested"
                    email_template_name = "main/password/password_reset_email.txt"
                    c = {
                        "email":user.email,
                        'domain':'127.0.0.1:8000',
                        'site_name': 'Website',
                        "uid": urlsafe_base64_encode(force_bytes(user.pk)),
                        "user": user,
                        'token': default_token_generator.make_token(user),
                        'protocol': 'http',
                    }
                    email = render_to_string(email_template_name, c)
                    try:
                        send_mail(subject, email, 'admin@example.com', [user.email], fail_silently=False)
                    except BadHeaderError:
                        return HttpResponse('Invalid header found.')
                    return redirect("/password_reset/done/")
    password_reset_form = PasswordResetForm()
    return render(request=request, template_name="password_reset.html", context={"password_reset_form":password_reset_form})
def chart(request):
    name = []
    saving = []
    profit=[]
    bb=[]
    nbb=[]
    queryset = Account.objects.all()
    for acc in queryset:
        nbb.append(acc.New_bank_balance)
        bb.append(acc.Bank_balance)
        name.append(acc.C_name)
        saving.append(acc.saving)
        profit.append(acc.shares_profit)
    context={
        'nbb': nbb,
        'bb': bb,
        'name': name,
        'saving': saving,
        'profit': profit,
    }
    return render(request,'chart.html',context)
def generateOTP():
    # Declare a digits variable
    # which stores all digits
    digits = "0123456789"
    OTP = ""

    # length of password can be chaged
    # by changing value in range
    for i in range(6):
        OTP += digits[math.floor(random.random() * 10)]
    print(OTP)
    return OTP
@login_required()
def index(request):
    return HttpResponse("Congrats, you're now logged in!")