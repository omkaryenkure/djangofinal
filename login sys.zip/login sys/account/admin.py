from django.contrib import admin
from .models import*
admin.site.site_header = 'ACCOUNT MANAGEMENT'
# Register your models here.
class ProfileAdmin(admin.ModelAdmin) :
    search_fields = ['C_name','bank_name','IFSC_code']
    list_display = ['C_name','bank_name','IFSC_code','Address','city']
admin.site.register(Profile,ProfileAdmin)

class AccountAdmin(admin.ModelAdmin):
    list_display = ['Salary','Bank_balance', 'saving','New_bank_balance']
admin.site.register(Account,AccountAdmin)
