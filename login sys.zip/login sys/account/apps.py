from django.apps import AppConfig


class AccConfig(AppConfig):
    name = 'Acc'
